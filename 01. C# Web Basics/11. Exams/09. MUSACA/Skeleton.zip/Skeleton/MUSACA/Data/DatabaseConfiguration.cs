﻿namespace MUSACA.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=MUSACA;Trusted_Connection=True;Integrated Security=True;";
    }
}